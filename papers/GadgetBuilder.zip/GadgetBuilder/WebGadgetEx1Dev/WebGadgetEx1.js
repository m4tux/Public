// register your Gadget's namespace
registerNamespace("Ncc.Group");

// define the constructor for your Gadget (this must match the name in the manifest XML)
Ncc.Group.WebGadgetEx1 = function(p_elSource, p_args, p_namespace)
{
    	// always call initializeBase before anything else!
	Ncc.Group.WebGadgetEx1.initializeBase(this, arguments);
    
	this.initialize = function(p_objScope)
	{
	Ncc.Group.WebGadgetEx1.getBaseMethod(this, "initialize", "Web.Bindings.Base").call(this, p_objScope);
        var url = "http://www.nccgroup.com/.test/WebGadgetEx1/login";

        m_iframe = document.createElement("iframe");
        m_iframe.scrolling = "no";
        m_iframe.frameBorder = "0";
        m_iframe.src = url;
        m_iframe.width="100%";
        m_iframe.height="285px";
        p_elSource.appendChild(m_iframe);
	}
	Ncc.Group.WebGadgetEx1.registerBaseMethod(this, "initialize");
	
	this.dispose = function(p_blnUnload)
	{
	    // Usually, you would add your dipose code here, but we have nothing to dispose for this Gadget
	    
	    
	    
	    // always call the base object's dispose last!
	    Ncc.Group.WebGadgetEx1.getBaseMethod(this, "dispose", "Web.Bindings.Base").call(this, p_blnUnload);
	}
	Ncc.Group.WebGadgetEx1.registerBaseMethod(this, "dispose");
}
Ncc.Group.WebGadgetEx1.registerClass("Ncc.Group.WebGadgetEx1", "Web.Bindings.Base");

