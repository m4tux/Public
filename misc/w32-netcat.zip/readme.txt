Exploit situation recreation.
-----------------------------
This archive contains the compiled exploit binary, vulnerable program
and a sample binary for use with the -e options. The source for the 
sample binary is included. The reason for using a simple, none 
functional executable was to minimize the number of different 
variables influencing the success of the attack.

Simulation
----------
run nc.exe with the following options.

 nc.exe -e prog.exe -v -v -L -p 81 -d

then the vulnerable system can be compromised with the exploit.
